import os
from dotenv import load_dotenv
import google.generativeai as genai

# Load API Key from .env
load_dotenv()

api_key = os.getenv("GEMINI_API_KEY")


if not api_key:
    raise ValueError("GEMINI_API_KEY not found in .env file")

# Configure Gemini
genai.configure(api_key=api_key)

# Load Gemini Model
model = genai.GenerativeModel("gemini-2.0-flash")

print("=" * 60)
print("Gemini AI Connected Successfully!")
print("=" * 60)
# Read meeting transcript
with open("sample_meeting.txt", "r", encoding="utf-8") as file:
    meeting_text = file.read()

print("\n" + "=" * 60)
print("MEETING TRANSCRIPT")
print("=" * 60)
print(meeting_text)
print("\n" + "=" * 60)
print("AI MEETING SUMMARY")
print("=" * 60)

prompt = f"""
You are an AI Meeting Assistant.

Analyze the following meeting transcript.

Return:
1. Meeting Summary
2. Action Items
3. Owners
4. Due Dates

Meeting Transcript:
{meeting_text}
"""

try:
    response = model.generate_content(prompt)
    print(response.text)

except Exception as e:
    print("AI Summary unavailable:", e)